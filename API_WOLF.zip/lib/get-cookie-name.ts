export default function MY_TOKEN_KEY() {
  return "deepsite-auth-token";
}
